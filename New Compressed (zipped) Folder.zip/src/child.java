
public class child extends parent {
        void work()
        {
        	System.out.println("Always work");
        }
	
	public static void main(String[] args) {
		child c = new child();
		System.out.println(c.psalary);
        c.salary();
	}

}
