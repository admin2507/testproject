
public class Animal {
  void type ()
  {
	  System.out.println("There are many types of animals");
  }
}
