import package1.prog1;  // accessed the prog1 from another package

public class Hello extends prog1 {
          
	public static void main(String[] args) {
		 Hello h = new Hello();
         h.batch();
         System.out.println("Hello World");

	}

}
