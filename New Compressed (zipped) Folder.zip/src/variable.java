
public class variable {
         //datattypes 
        
	public static void main(String[] args) {
		int a = 10;
        float f = 0.01f;
        double d = 55.88;	
        String s = "test";
		System.out.println("value is  "+a);
		System.out.println("Name is "+s);
		System.out.println("value of number "+d);
		System.out.println("value is "+f);

	}

}
