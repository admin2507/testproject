
public class object {

	public static void main(String[] args) {
		object b = new object();   // object creation always have new keyword
		System.out.println(b);  // b is the reference where object is stored

	}

}
