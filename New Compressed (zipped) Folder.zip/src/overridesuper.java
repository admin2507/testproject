
public class overridesuper {

	void drink ()
	{
		System.out.println("Lemon tea");
	}
}
