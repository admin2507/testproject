
public class upcasting1 {
      int a = 10;
      int b = 20;
      int c = a+b;
      int add ()
      {
    	  System.out.println("this is add method");
    	  return c;
      }
      
      void play()
      {
    	  System.out.println("I love playing outside");
      }
    		 
}
