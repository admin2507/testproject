
public class cat extends Animal {   //Hierarchial inheritance

	public static void main(String[] args) {
		cat c = new cat();
	    c.type();

	}

}
