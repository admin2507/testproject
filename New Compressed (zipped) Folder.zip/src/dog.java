
public class dog extends Animal {  //Hierarchial inheritance

	public static void main(String[] args) {
		dog d = new dog();
		d.type();

	}

}
