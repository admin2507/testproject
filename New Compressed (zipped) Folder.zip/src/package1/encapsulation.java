package package1;

public class encapsulation {
	private int sid;

	// use of getter/setter to use private varibale in another class
	
	public int getSid() {
		return sid;
	}

	public void setSid(int sid) {
		this.sid = sid;
	}

}
