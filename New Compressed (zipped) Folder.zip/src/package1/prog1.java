package package1;

public class prog1 {
	protected void batch()
	{
		System.out.println("this is package 1 class");
	}

}
