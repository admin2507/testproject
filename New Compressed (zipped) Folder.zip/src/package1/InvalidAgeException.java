package package1;

public class InvalidAgeException extends Exception {
	public InvalidAgeException() {
		super();
	}
	

}
