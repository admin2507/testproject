package package1;

public class circle extends shape {

	@Override
	void display() {
		System.out.println("Shape is circle");
		
	}

}
