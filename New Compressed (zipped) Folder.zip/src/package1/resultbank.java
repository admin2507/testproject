package package1;

public class resultbank {

	public static void main(String[] args) {
		bank_interface b = new PNB1();
		b.getroi();
		
		bank_interface c = new SBI();
		c.getroi();
	}

}
