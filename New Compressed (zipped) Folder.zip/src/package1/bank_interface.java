package package1;

public interface bank_interface {

	void getroi();
}
