package package1;

import java.util.Scanner;

public class ArrayEvenNo {

	public static void main(String[] args) {
	Scanner s = new Scanner(System.in);  // scanner class 
		System.out.println("Input value");
		//int size = s.nextInt();
		int ar[]= new int[s.nextInt()];
		/*System.out.println("pass the data");
		for (int i=0;i<ar.length;i++)
		{
		  ar[i]= s.nextInt();	// assigning value to the indexes 
		
		}
		System.out.println("Even no ");
		for(int i=0; i<ar.length;i++)
		{   
			if(ar[i]%2==0) {
				System.out.println(ar[i]);
			}
			
		}
		System.out.println("Odd no ");
		for(int i=0; i<ar.length;i++)
		{   
			if(ar[i]%2!=0) {
				System.out.println(ar[i]);
			}
			
		}*/

		while(true) {
			System.out.println(s.nextInt());   // imp q > run n no of times
		}
		
        
	}

}
