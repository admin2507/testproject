package package1;

public class PNB extends bank {

	@Override
	void getrateofintrest() {
		System.out.println("Rate of interest is 6.15%");
	}

}
