package package1;

public interface interface2 {
	public void getroid();

}
