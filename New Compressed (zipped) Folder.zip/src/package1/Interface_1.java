package package1;

public interface Interface_1 {
	void draw();

}
