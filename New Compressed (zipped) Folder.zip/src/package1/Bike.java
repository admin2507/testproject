package package1;
//abstract class with abstract method
public abstract class Bike {

	abstract void drive();
	
	void run ()
	{
		System.out.println("Run fast");
	}
}
