package package1;

public class Test_Bank {

	public static void main(String[] args) {
		bank b = new PNB();
		bank b1 = new BOI();
		b.getrateofintrest();
		b1.getrateofintrest();

	}

}
