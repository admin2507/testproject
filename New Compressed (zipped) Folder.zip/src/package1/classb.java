package package1;

public class classb implements Interface_1 {

	@Override
	public void draw() {
              System.out.println("This is classb");		
	}

}
