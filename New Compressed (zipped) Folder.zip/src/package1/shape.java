package package1;

public abstract class shape {
           abstract void display();
}
