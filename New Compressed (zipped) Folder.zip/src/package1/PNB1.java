package package1;

public class PNB1 implements bank_interface {

	@Override
	public void getroi() {
		System.out.println("The ROI is 7%");
		
	}

}
