package package1;

public class BOI extends bank {

	@Override
	void getrateofintrest() {
		System.out.println("Rate of interest is 6.25%");
		
	}

}
