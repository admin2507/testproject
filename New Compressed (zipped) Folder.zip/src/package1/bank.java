package package1;

public abstract class bank {
         abstract void getrateofintrest();
}
