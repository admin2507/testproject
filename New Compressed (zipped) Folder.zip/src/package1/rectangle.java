package package1;

public class rectangle extends shape{

	@Override
	void display() {
		System.out.println("shape is rectangle");
		
	}

}
