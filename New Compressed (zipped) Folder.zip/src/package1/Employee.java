package package1;

public class Employee {
	private int empId;
	private int empSal;
	private int empDept;
	private String empName;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public int getEmpSal() {
		return empSal;
	}
	public void setEmpSal(int empSal) {
		this.empSal = empSal;
	}
	public int getEmpDept() {
		return empDept;
	}
	public void setEmpDept(int empDept) {
		this.empDept = empDept;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}

}
