package package1;

public class interface_classa implements Interface_1{

	@Override
	public void draw() {
		System.out.println("This is class a");		
	}

}
