
public class parent {

	double psalary = 55.66;
	void salary()
	{
		System.out.println("Salary is good");
	}
}
