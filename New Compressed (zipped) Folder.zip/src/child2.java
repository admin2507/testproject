
public class child2 extends child {  // multi level inheritance

	public static void main(String[] args) {
		child2 c2 = new child2();
		c2.salary();
		c2.work();

	}

}
